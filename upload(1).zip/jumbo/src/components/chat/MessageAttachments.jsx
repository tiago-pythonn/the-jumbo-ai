import { Download, FileText } from "lucide-react";
import { Image } from "@/components/ui/image";

const isImage = (attachment) => (attachment.type || "").startsWith("image/");

export default function MessageAttachments({ attachments }) {
  if (!attachments?.length) return null;
  const images = attachments.filter(isImage);
  const files = attachments.filter((attachment) => !isImage(attachment));

  return (
    <div className="space-y-2">
      {images.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {images.map((attachment) => (
            <a
              key={attachment.url}
              href={attachment.url}
              target="_blank"
              rel="noreferrer"
              className="block overflow-hidden rounded-xl border border-border"
            >
              <Image
                src={attachment.url}
                alt={attachment.name || "Anexo"}
                fittingType="fill"
                className="h-36 w-36 object-cover sm:h-44 sm:w-44"
              />
            </a>
          ))}
        </div>
      )}

      {files.map((attachment) => (
        <a
          key={attachment.url}
          href={attachment.url}
          target="_blank"
          rel="noreferrer"
          className="flex w-fit max-w-full items-center gap-2 rounded-lg border border-border bg-secondary/60 px-3 py-2 text-xs transition-colors hover:border-primary/40"
        >
          <FileText className="h-4 w-4 shrink-0 text-primary" />
          <span className="truncate">{attachment.name}</span>
          <Download className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        </a>
      ))}
    </div>
  );
}