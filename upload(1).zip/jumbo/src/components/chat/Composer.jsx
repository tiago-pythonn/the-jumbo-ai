import { useEffect, useRef, useState } from "react";
import { ArrowUp, FileText, Paperclip, X } from "lucide-react";

const MAX_FILES = 10;

export default function Composer({ onSend, busy, placeholder = "Pergunte qualquer coisa ao Jumbo" }) {
  const [value, setValue] = useState("");
  const [files, setFiles] = useState([]);
  const ref = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    element.style.height = "auto";
    element.style.height = `${Math.min(element.scrollHeight, 200)}px`;
  }, [value]);

  function addFiles(list) {
    const incoming = Array.from(list ?? []);
    if (!incoming.length) return;
    setFiles((previous) => [...previous, ...incoming].slice(0, MAX_FILES));
  }

  function submit() {
    const text = value.trim();
    if ((!text && files.length === 0) || busy) return;
    onSend(text, files);
    setValue("");
    setFiles([]);
  }

  function onKeyDown(event) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-4">
      {files.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-2">
          {files.map((file, index) => (
            <span
              key={`${file.name}-${index}`}
              className="flex items-center gap-2 rounded-lg border border-border bg-card px-2.5 py-1.5 text-xs"
            >
              <FileText className="h-3.5 w-3.5 shrink-0 text-primary" />
              <span className="max-w-[160px] truncate">{file.name}</span>
              <button
                type="button"
                onClick={() => setFiles((previous) => previous.filter((_, i) => i !== index))}
                aria-label={`Remover ${file.name}`}
                className="text-muted-foreground transition-colors hover:text-destructive"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </span>
          ))}
        </div>
      )}

      <div className="flex items-end gap-2 rounded-2xl border border-border bg-card p-2 shadow-lg shadow-black/20 transition-colors focus-within:border-primary/50">
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(event) => {
            addFiles(event.target.files);
            event.target.value = "";
          }}
        />
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          aria-label="Anexar arquivo"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Paperclip className="h-4.5 w-4.5" />
        </button>
        <textarea
          ref={ref}
          rows={1}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          onKeyDown={onKeyDown}
          placeholder={placeholder}
          aria-label="Mensagem para o Jumbo"
          className="max-h-[200px] flex-1 resize-none bg-transparent px-2.5 py-2 text-[15px] leading-relaxed text-foreground placeholder:text-muted-foreground focus:outline-none"
        />
        <button
          type="button"
          onClick={submit}
          disabled={(!value.trim() && files.length === 0) || busy}
          aria-label="Enviar mensagem"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground"
        >
          <ArrowUp className="h-4 w-4" />
        </button>
      </div>
      <p className="mt-2 text-center text-[11px] text-muted-foreground">
        O Jumbo pode cometer erros. Confira informações importantes.
      </p>
    </div>
  );
}