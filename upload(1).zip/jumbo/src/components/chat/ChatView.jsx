import { useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AlertCircle } from "lucide-react";
import Composer from "@/components/chat/Composer";
import MessageBubble from "@/components/chat/MessageBubble";
import WelcomeScreen from "@/components/chat/WelcomeScreen";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { sendMessage } from "@/lib/chat-fns";

function TypingBubble() {
  return (
    <div className="flex items-center gap-1.5 px-1 py-2" aria-label="Jumbo está digitando">
      {[0, 150, 300].map((delay) => (
        <span
          key={delay}
          className="h-1.5 w-1.5 animate-bounce rounded-full bg-primary"
          style={{ animationDelay: `${delay}ms` }}
        />
      ))}
    </div>
  );
}

export default function ChatView({ conversationId = null, initialMessages = [] }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState(initialMessages);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const bottomRef = useRef(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const send = useServerFn(sendMessage);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function handleSend(text, files = []) {
    if (busy) return;
    setError("");
    const optimistic = {
      id: `local-${Date.now()}`,
      role: "user",
      content: text,
      attachments: files.map((file) => ({
        name: file.name,
        type: file.type,
        url: URL.createObjectURL(file),
      })),
    };
    setMessages((previous) => [...previous, optimistic]);
    setBusy(true);
    try {
      const attachments = await Promise.all(
        files.map(async (file) => {
          const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
          return { name: file.name, url: file_url, type: file.type };
        }),
      );
      const result = await send({ data: { conversationId, content: text, attachments } });
      setMessages((previous) => [...previous, result.message]);
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
      if (!conversationId) {
        navigate({
          to: "/c/$conversationId",
          params: { conversationId: result.conversationId },
          replace: true,
        });
      }
    } catch {
      setError("O Jumbo não conseguiu responder agora. Tente novamente em instantes.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex h-full flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto">
        {messages.length === 0 ? (
          <WelcomeScreen userName={user?.full_name} onPick={handleSend} />
        ) : (
          <div className="mx-auto w-full max-w-3xl space-y-6 px-4 py-6">
            {messages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
            {busy && <TypingBubble />}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      {error && (
        <div className="mx-auto mb-2 flex w-full max-w-3xl items-center gap-2 px-4 text-sm text-destructive">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}

      <Composer onSend={handleSend} busy={busy} />
    </div>
  );
}