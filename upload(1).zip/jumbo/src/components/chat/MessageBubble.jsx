import JumboLogo from "@/components/brand/JumboLogo";
import MarkdownMessage from "@/components/chat/MarkdownMessage";
import MessageAttachments from "@/components/chat/MessageAttachments";

export default function MessageBubble({ message }) {
  if (message.role === "user") {
    return (
      <div className="flex justify-end">
        <div className="max-w-[85%] space-y-2 rounded-2xl rounded-br-md border border-primary/25 bg-primary/15 px-4 py-2.5 text-[15px] leading-relaxed text-foreground sm:max-w-[70%]">
          <MessageAttachments attachments={message.attachments} />
          {message.content && <div className="whitespace-pre-wrap">{message.content}</div>}
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3">
      <JumboLogo className="mt-0.5 h-7 w-7 shrink-0 rounded-lg" />
      <div className="min-w-0 flex-1">
        <p className="mb-1 font-heading text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground">
          Jumbo
        </p>
        <MarkdownMessage content={message.content} />
      </div>
    </div>
  );
}