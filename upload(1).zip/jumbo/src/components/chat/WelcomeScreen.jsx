import { Code2, Lightbulb, PenLine, Sparkles } from "lucide-react";
import JumboLogo from "@/components/brand/JumboLogo";

const suggestions = [
  { icon: Lightbulb, label: "Explique energia solar como se eu tivesse 10 anos" },
  { icon: Code2, label: "Escreva uma função em JavaScript que valida um CPF" },
  { icon: PenLine, label: "Crie um roteiro de vídeo curto sobre produtividade" },
];

export default function WelcomeScreen({ userName, onPick }) {
  const firstName = userName?.trim()?.split(" ")[0];

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col items-center px-4 pb-8 pt-10 text-center sm:pt-20">
      <JumboLogo className="h-14 w-14 rounded-2xl shadow-lg shadow-primary/20" />
      <h1 className="mt-5 font-heading text-3xl font-semibold tracking-tight sm:text-4xl">
        {firstName ? `Olá, ${firstName}` : "Olá"}
      </h1>
      <p className="mt-2 max-w-md text-[15px] text-muted-foreground">
        Sou o Jumbo. Posso escrever, explicar, resumir e programar com você. Como posso ajudar hoje?
      </p>

      <div className="mt-8 grid w-full gap-2.5 sm:grid-cols-3">
        {suggestions.map(({ icon: Icon, label }) => (
          <button
            key={label}
            type="button"
            onClick={() => onPick(label)}
            className="group flex flex-col items-start gap-2 rounded-xl border border-border bg-card/70 p-3.5 text-left transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:bg-card"
          >
            <Icon className="h-4 w-4 text-primary" />
            <span className="text-[13px] leading-snug text-muted-foreground group-hover:text-foreground">
              {label}
            </span>
          </button>
        ))}
      </div>

      <p className="mt-8 flex items-center gap-1.5 text-[11px] uppercase tracking-[0.16em] text-muted-foreground/70">
        <Sparkles className="h-3 w-3" /> Powered by Jumbo IA
      </p>
    </div>
  );
}