import { Link, useNavigate } from "@tanstack/react-router";
import { LogOut, Plus, ShieldCheck, Trash2, User } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import JumboLogo from "@/components/brand/JumboLogo";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";
import { useConversations } from "@/hooks/useConversations";
import { deleteConversation } from "@/lib/chat-fns";

function initials(name, email) {
  const source = (name || email || "J").trim();
  const parts = source.split(/\s+/).slice(0, 2);
  return parts.map((p) => p[0]?.toUpperCase() ?? "").join("") || "J";
}

export default function Sidebar({ onNavigate }) {
  const { user, logout } = useAuth();
  const { data: conversations = [], isLoading } = useConversations(user?.id);
  const remove = useServerFn(deleteConversation);
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [busyId, setBusyId] = useState(null);

  async function handleDelete(event, conversation) {
    event.preventDefault();
    event.stopPropagation();
    setBusyId(conversation.id);
    try {
      await remove({ data: { id: conversation.id } });
      await queryClient.invalidateQueries({ queryKey: ["conversations"] });
      if (window.location.pathname === `/c/${conversation.id}`) {
        navigate({ to: "/" });
      }
    } catch {
      toast.error("Não foi possível excluir a conversa.");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex items-center gap-2.5 px-4 pb-2 pt-5">
        <JumboLogo className="h-8 w-8 rounded-lg" />
        <span className="font-heading text-xl font-semibold tracking-tight">Jumbo</span>
      </div>

      <div className="px-3 pb-3 pt-2">
        <Button asChild className="h-11 w-full justify-start gap-2 rounded-xl text-sm font-medium">
          <Link to="/" onClick={onNavigate}>
            <Plus className="h-4 w-4" />
            Novo chat
          </Link>
        </Button>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-2">
        <p className="px-2 pb-2 pt-2 text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          Conversas
        </p>
        {isLoading ? (
          <div className="space-y-1.5 px-1">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-9 animate-pulse rounded-lg bg-sidebar-accent/60" />
            ))}
          </div>
        ) : conversations.length === 0 ? (
          <p className="px-3 py-6 text-sm text-muted-foreground">Nenhuma conversa ainda.</p>
        ) : (
          <ul className="space-y-0.5">
            {conversations.map((conversation) => (
              <li key={conversation.id}>
                <Link
                  to="/c/$conversationId"
                  params={{ conversationId: conversation.id }}
                  onClick={onNavigate}
                  activeProps={{ className: "bg-sidebar-accent text-sidebar-accent-foreground" }}
                  className="group flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground"
                >
                  <span className="line-clamp-1 flex-1 text-left">{conversation.title}</span>
                  <button
                    type="button"
                    aria-label="Excluir conversa"
                    disabled={busyId === conversation.id}
                    onClick={(event) => handleDelete(event, conversation)}
                    className="rounded p-1 text-muted-foreground opacity-0 transition-opacity hover:text-destructive focus:opacity-100 group-hover:opacity-100"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="border-t border-sidebar-border p-3">
        <Link
          to="/profile"
          onClick={onNavigate}
          className="flex items-center gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-sidebar-accent"
        >
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 text-sm font-semibold text-white">
            {initials(user?.full_name, user?.email)}
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-medium">{user?.full_name || "Meu perfil"}</span>
            <span className="block truncate text-xs text-muted-foreground">{user?.email}</span>
          </span>
        </Link>

        <div className="mt-1 space-y-0.5">
          <Link
            to="/profile"
            onClick={onNavigate}
            className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
          >
            <User className="h-4 w-4" />
            Perfil e configurações
          </Link>
          <Link
            to="/api-keys"
            onClick={onNavigate}
            className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
          >
            <ShieldCheck className="h-4 w-4" />
            API keys
          </Link>
          {user?.role === "admin" && (
            <Link
              to="/admin"
              onClick={onNavigate}
              className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
            >
              <ShieldCheck className="h-4 w-4" />
              Administração
            </Link>
          )}
          <button
            type="button"
            onClick={logout}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
          >
            <LogOut className="h-4 w-4" />
            Sair
          </button>
        </div>
      </div>
    </div>
  );
}