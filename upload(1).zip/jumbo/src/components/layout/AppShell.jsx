import { Outlet } from "@tanstack/react-router";
import { Menu } from "lucide-react";
import { useState } from "react";
import JumboLogo from "@/components/brand/JumboLogo";
import Sidebar from "@/components/layout/Sidebar";

export default function AppShell() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);

  return (
    <div className="flex h-[100dvh] w-full overflow-hidden bg-background text-foreground">
      <aside className="hidden w-[272px] shrink-0 border-r border-sidebar-border md:block">
        <Sidebar />
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={close}
            aria-hidden="true"
          />
          <div className="absolute inset-y-0 left-0 w-[280px] animate-in slide-in-from-left border-r border-sidebar-border shadow-2xl duration-200">
            <Sidebar onNavigate={close} />
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-border px-3 md:hidden">
          <button
            type="button"
            onClick={() => setOpen(true)}
            aria-label="Abrir menu"
            className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <Menu className="h-5 w-5" />
          </button>
          <JumboLogo className="h-7 w-7 rounded-lg" />
          <span className="font-heading text-lg font-semibold tracking-tight">Jumbo</span>
        </header>

        <main className="min-h-0 flex-1 overflow-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}