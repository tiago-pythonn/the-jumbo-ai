import JumboLogo from "@/components/brand/JumboLogo";

// Full-screen card shared by the auth pages; it sets its own color tokens so it stays readable under any theme.
export function AuthLayout({ title, subtitle, footer, children }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4 py-10 text-foreground">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-48 left-1/2 h-[26rem] w-[26rem] -translate-x-1/2 rounded-full bg-primary/25 blur-[130px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-chart-2/15 blur-[120px]"
      />

      <div className="relative w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mb-5 flex items-center justify-center gap-2.5">
            <JumboLogo className="h-11 w-11 rounded-xl shadow-lg shadow-primary/30" />
            <span className="font-heading text-2xl font-semibold tracking-tight">Jumbo</span>
          </div>
          <h1 className="font-heading text-3xl font-bold tracking-tight">{title}</h1>
          {subtitle && <p className="mx-auto mt-2 max-w-xs text-sm text-muted-foreground">{subtitle}</p>}
        </div>

        <div className="rounded-3xl border border-border bg-card/80 p-7 shadow-2xl shadow-black/40 backdrop-blur-sm sm:p-8">
          {children}
        </div>

        {footer && <p className="mt-6 text-center text-sm text-muted-foreground">{footer}</p>}
        <p className="mt-6 text-center text-[11px] text-muted-foreground">
          Seus dados ficam na sua conta. Conversas privadas, sempre.
        </p>
      </div>
    </div>
  );
}