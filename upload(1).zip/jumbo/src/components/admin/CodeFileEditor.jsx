import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { joinCode } from "@/lib/code-split";
import { saveCodeFile } from "@/lib/code-files-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function CodeFileEditor({ file, onClose, onSaved }) {
  const save = useServerFn(saveCodeFile);
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["admin", "code", "file", file.id],
    queryFn: () => base44.entities.CodeFile.get(file.id),
  });

  useEffect(() => {
    if (data) setDraft(joinCode(data));
  }, [data]);

  async function handleSave() {
    setSaving(true);
    try {
      await save({ data: { id: file.id, content: draft } });
      await onSaved();
      toast.success("Arquivo salvo.", { description: file.path });
      onClose();
    } catch {
      toast.error("Não foi possível salvar o arquivo.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl rounded-2xl">
        <DialogHeader>
          <DialogTitle className="truncate font-mono text-sm">{file.path}</DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="h-[55vh] animate-pulse rounded-xl bg-muted/40" />
        ) : (
          <textarea
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            spellCheck={false}
            aria-label={`Código de ${file.path}`}
            className="h-[55vh] w-full resize-none rounded-xl border border-border bg-background p-3 font-mono text-xs leading-relaxed outline-none focus:border-primary/50"
          />
        )}

        <div className="flex items-center justify-between gap-3">
          <p className="text-[11px] text-muted-foreground">{draft.length} caracteres</p>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onClose} className="rounded-xl">
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={saving || isLoading} className="rounded-xl">
              {saving ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Salvar arquivo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}