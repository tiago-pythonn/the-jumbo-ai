import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Download, FileArchive, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { exportData } from "@/lib/admin-fns";
import { saveBlob } from "@/lib/download";
import { collectSourceFiles } from "@/lib/source-files";
import { createZip } from "@/lib/zip";

export default function DataExport() {
  const [busy, setBusy] = useState(false);
  const [zipBusy, setZipBusy] = useState(false);
  const run = useServerFn(exportData);

  async function downloadAnalysis() {
    setBusy(true);
    try {
      const data = await run();
      if (!data?.authorized) {
        toast.error("Apenas administradores podem exportar os dados.");
        return;
      }
      saveBlob(
        new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }),
        "analise.json",
      );
      toast.success("Arquivo analise.json gerado.", {
        description: `${data.conversations.length} conversa(s) e ${data.users.length} usuário(s).`,
      });
    } catch {
      toast.error("Não foi possível gerar o arquivo agora.");
    } finally {
      setBusy(false);
    }
  }

  async function downloadCode() {
    setZipBusy(true);
    try {
      const files = collectSourceFiles();
      saveBlob(createZip(files), "upload.zip");
      toast.success("upload.zip gerado.", {
        description: `${files.length} arquivos de código do Jumbo.`,
      });
    } catch {
      toast.error("Não foi possível gerar o .zip agora.");
    } finally {
      setZipBusy(false);
    }
  }

  return (
    <div className="mb-6 rounded-2xl border border-border bg-card p-5">
      <h2 className="font-heading text-sm font-semibold">Downloads</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Baixe as conversas e usuários para análise, ou o código completo do Jumbo em .zip.
      </p>

      <div className="mt-4 flex flex-wrap gap-3">
        <Button onClick={downloadAnalysis} disabled={busy} className="rounded-xl">
          {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
          Conversas e usuários (analise.json)
        </Button>
        <Button
          onClick={downloadCode}
          disabled={zipBusy}
          variant="outline"
          className="rounded-xl"
        >
          {zipBusy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileArchive className="mr-2 h-4 w-4" />}
          Código do Jumbo (upload.zip)
        </Button>
      </div>
    </div>
  );
}