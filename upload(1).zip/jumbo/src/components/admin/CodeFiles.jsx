import { useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Code2, Download, Loader2, Search, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import CodeFileEditor from "@/components/admin/CodeFileEditor";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { joinCode, MAX_FILE_CHARS } from "@/lib/code-split";
import { deleteCodeFile, importCodeFiles } from "@/lib/code-files-fns";
import { saveBlob } from "@/lib/download";
import { collectSourceFiles } from "@/lib/source-files";
import { createZip } from "@/lib/zip";
import { collectImportedFiles } from "@/lib/zip-reader";

const items = (result) => result?.items ?? result ?? [];

const formatSize = (size = 0) => (size >= 1024 ? `${Math.round(size / 1024)} KB` : `${size} B`);

export default function CodeFiles() {
  const queryClient = useQueryClient();
  const importFiles = useServerFn(importCodeFiles);
  const removeFile = useServerFn(deleteCodeFile);
  const inputRef = useRef(null);
  const [importing, setImporting] = useState(false);
  const [zipBusy, setZipBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState(null);

  const { data: files = [], isLoading } = useQuery({
    queryKey: ["admin", "code"],
    queryFn: async () => {
      const result = await base44.entities.CodeFile.filter({}, { sort: "path", limit: 400 });
      return items(result).map((file) => ({
        id: file.id,
        path: file.path,
        size: file.size ?? (file.content ?? "").length,
      }));
    },
  });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["admin", "code"] });

  async function importEntries(entries) {
    const usable = entries
      .filter((entry) => entry.content.length <= MAX_FILE_CHARS)
      .map((entry) => ({ path: entry.path, content: entry.content }));
    const skipped = entries.length - usable.length;
    if (!usable.length) {
      toast.error("Nenhum arquivo de código encontrado no envio.");
      return;
    }

    const { created, updated } = await importFiles({ data: { files: usable } });

    toast.success(`${usable.length} arquivo(s) na biblioteca.`, {
      description: `${created} novo(s), ${updated} atualizado(s).${
        skipped ? ` ${skipped} arquivo(s) grande(s) demais ficaram de fora.` : ""
      }`,
    });
    await refresh();
  }

  async function onPick(event) {
    const picked = event.target.files;
    event.target.value = "";
    if (!picked?.length) return;
    setImporting(true);
    try {
      await importEntries(await collectImportedFiles(picked));
    } catch (error) {
      toast.error("Não foi possível ler os arquivos enviados.", {
        description: String(error?.message ?? error).slice(0, 180),
      });
    } finally {
      setImporting(false);
    }
  }

  async function loadCurrent() {
    setImporting(true);
    try {
      const entries = collectSourceFiles()
        .map((file) => ({ path: file.name.replace(/^jumbo\//, ""), content: file.content }))
        .filter((entry) => !entry.path.endsWith(".server.js"));
      await importEntries(entries);
    } catch (error) {
      toast.error("Não foi possível carregar o código atual.", {
        description: String(error?.message ?? error).slice(0, 180),
      });
    } finally {
      setImporting(false);
    }
  }

  async function download() {
    setZipBusy(true);
    try {
      const entries = items(
        await base44.entities.CodeFile.filter({}, { sort: "path", limit: 400 }),
      );
      if (!entries.length) {
        toast.error("A biblioteca está vazia. Importe os arquivos primeiro.");
        return;
      }
      saveBlob(
        createZip(entries.map((file) => ({ name: file.path, content: joinCode(file) }))),
        "upload.zip",
      );
      toast.success("upload.zip gerado.", { description: `${entries.length} arquivos.` });
    } catch (error) {
      toast.error("Não foi possível gerar o .zip agora.", {
        description: String(error?.message ?? error).slice(0, 180),
      });
    } finally {
      setZipBusy(false);
    }
  }

  async function remove(file) {
    await removeFile({ data: { id: file.id } });
    await refresh();
    toast.success("Arquivo removido.", { description: file.path });
  }

  const term = search.trim().toLowerCase();
  const visible = term ? files.filter((file) => file.path.toLowerCase().includes(term)) : files;

  return (
    <div className="mb-6 rounded-2xl border border-border bg-card p-5">
      <h2 className="font-heading text-sm font-semibold">Código do Jumbo</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Importe o upload.zip (ou arquivos soltos), edite qualquer arquivo e baixe o pacote
        atualizado. Todos os usuários podem abrir os arquivos; só administradores editam.
      </p>

      <div className="mt-4 flex flex-wrap gap-3">
        <input
          ref={inputRef}
          type="file"
          multiple
          accept=".zip,.js,.jsx,.ts,.tsx,.css,.json,.jsonc,.md,.txt,.html,.yml,.yaml,.svg"
          className="hidden"
          onChange={onPick}
        />
        <Button onClick={() => inputRef.current?.click()} disabled={importing} className="rounded-xl">
          {importing ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Upload className="mr-2 h-4 w-4" />
          )}
          Importar arquivos
        </Button>
        <Button onClick={loadCurrent} disabled={importing} variant="secondary" className="rounded-xl">
          <Code2 className="mr-2 h-4 w-4" />
          Carregar código atual
        </Button>
        <Button onClick={download} disabled={zipBusy} variant="outline" className="rounded-xl">
          {zipBusy ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Download className="mr-2 h-4 w-4" />
          )}
          Baixar .zip
        </Button>
      </div>

      <div className="relative mt-4">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Buscar arquivo pelo caminho"
          aria-label="Buscar arquivo pelo caminho"
          className="h-9 rounded-xl pl-9 text-sm"
        />
      </div>

      <div className="mt-3 max-h-[380px] overflow-y-auto rounded-xl border border-border">
        {isLoading ? (
          <div className="h-24 animate-pulse bg-muted/40" />
        ) : visible.length === 0 ? (
          <p className="px-4 py-6 text-center text-sm text-muted-foreground">
            {files.length === 0
              ? "Nenhum arquivo importado ainda. Use “Importar arquivos” ou “Carregar código atual”."
              : "Nenhum arquivo encontrado para essa busca."}
          </p>
        ) : (
          <ul className="divide-y divide-border/60">
            {visible.map((file) => (
              <li key={file.id} className="flex items-center gap-1 pr-1">
                <button
                  type="button"
                  onClick={() => setEditing(file)}
                  className="flex min-w-0 flex-1 items-center gap-2 px-3 py-2 text-left transition-colors hover:bg-accent"
                >
                  <Code2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                  <span className="truncate font-mono text-xs">{file.path}</span>
                  <span className="ml-auto shrink-0 pl-2 text-[11px] text-muted-foreground">
                    {formatSize(file.size)}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => remove(file)}
                  aria-label={`Remover ${file.path}`}
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/15 hover:text-destructive"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {editing && (
        <CodeFileEditor
          key={editing.id}
          file={editing}
          onClose={() => setEditing(null)}
          onSaved={refresh}
        />
      )}
    </div>
  );
}