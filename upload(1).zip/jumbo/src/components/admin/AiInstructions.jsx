import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { getAiInstructions, saveAiInstructions } from "@/lib/ai-settings-fns";

export default function AiInstructions() {
  const queryClient = useQueryClient();
  const load = useServerFn(getAiInstructions);
  const save = useServerFn(saveAiInstructions);
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "ai-instructions"],
    queryFn: () => load(),
  });
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (typeof data?.instructions === "string") setText(data.instructions);
  }, [data?.instructions]);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    try {
      const result = await save({ data: { instructions: text } });
      if (!result?.ok) {
        toast.error("Apenas administradores podem salvar as instruções.");
        return;
      }
      await queryClient.invalidateQueries({ queryKey: ["admin", "ai-instructions"] });
      toast.success("Instruções da IA salvas.");
    } catch {
      toast.error("Não foi possível salvar as instruções agora.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="mb-6 rounded-2xl border border-border bg-card p-5">
      <h2 className="font-heading text-sm font-semibold">Como o Jumbo deve responder</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Escreva o prompt com a personalidade, o tom e as regras do Jumbo. Vale para o chat do app e
        para a API pública.
      </p>

      {isLoading ? (
        <div className="mt-4 h-36 animate-pulse rounded-xl bg-muted/60" />
      ) : (
        <>
          <Label htmlFor="ai-instructions" className="sr-only">
            Instruções da IA
          </Label>
          <textarea
            id="ai-instructions"
            value={text}
            onChange={(event) => setText(event.target.value)}
            rows={7}
            maxLength={4000}
            placeholder="Ex.: Fale de forma direta e amigável, use listas curtas, responda sempre em português do Brasil e nunca invente dados."
            className="mt-3 w-full resize-y rounded-xl border border-border bg-background p-3 text-sm leading-relaxed outline-none transition-colors placeholder:text-muted-foreground focus:border-primary/60"
          />
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs text-muted-foreground">{text.length}/4000 caracteres</span>
            <Button type="submit" disabled={busy} className="rounded-xl">
              {busy ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="mr-2 h-4 w-4" />
              )}
              Salvar instruções
            </Button>
          </div>
        </>
      )}
    </form>
  );
}