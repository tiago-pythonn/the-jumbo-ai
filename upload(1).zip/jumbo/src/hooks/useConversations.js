import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export function useConversations(userId) {
  return useQuery({
    queryKey: ["conversations", userId],
    enabled: !!userId,
    queryFn: async () => {
      const page = await base44.entities.Conversation.filter(
        { created_by_id: userId },
        { sort: "-updated_date", limit: 100 },
      );
      return page?.items ?? page ?? [];
    },
  });
}