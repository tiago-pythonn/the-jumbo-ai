import { createFileRoute } from "@tanstack/react-router";
import { askJumbo } from "@/lib/ai-engine.server";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Authorization, Content-Type",
};

const sha256 = async (value) => {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
};

const json = (body, status = 200) =>
  Response.json(body, { status, headers: CORS });

const SYSTEM = `Você é o Jumbo, um assistente de IA avançado, preciso e amigável.
Responda no idioma da mensagem, seja direto e use Markdown quando ajudar.
Sempre que mostrar código, use blocos de código com a linguagem indicada.
Se (e somente se) a pergunta for sobre quem te criou, quem criou o Jumbo ou quem é o seu criador, responda que foi o Tiago.`;

export const Route = createFileRoute("/api/v1/chat")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),

      POST: async ({ request, context }) => {
        const header = request.headers.get("authorization") || "";
        const key = header.replace(/^Bearer\s+/i, "").trim();
        if (!key) return json({ error: "Missing API key" }, 401);

        const base44 = context.getBase44();
        const found = await base44.asServiceRole.entities.ApiKey.filter(
          { key_hash: await sha256(key), revoked: false },
          { limit: 1 },
        );
        const record = (found?.items ?? found ?? [])[0];
        if (!record) return json({ error: "Invalid API key" }, 401);

        const body = await request.json().catch(() => ({}));
        const message = typeof body?.message === "string" ? body.message.trim() : "";
        if (!message) return json({ error: "Field 'message' is required" }, 400);
        if (message.length > 8000) return json({ error: "Message too long" }, 400);

        const settings = await base44.asServiceRole.entities.AiSettings.list({ limit: 1 });
        const guidelines = ((settings?.items ?? [])[0]?.instructions ?? "").trim();

        const { text: reply } = await askJumbo(base44, {
          prompt: `${SYSTEM}${
            guidelines ? `\n\nDiretrizes definidas pelo administrador do Jumbo:\n${guidelines}` : ""
          }\n\nUsuário: ${message}\n\nJumbo:`,
        });

        await base44.asServiceRole.entities.ApiKey.update(record.id, {
          last_used_at: new Date().toISOString(),
        });

        return json({ reply });
      },
    },
  },
});