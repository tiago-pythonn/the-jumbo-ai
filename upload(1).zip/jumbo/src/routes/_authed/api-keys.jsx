import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { Check, Copy, KeyRound, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import PageContainer from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createApiKey, deleteApiKey, listApiKeys, revokeApiKey } from "@/lib/api-keys-fns";

export const Route = createFileRoute("/_authed/api-keys")({
  head: () => ({ meta: [{ title: "API keys · Jumbo" }] }),
  component: ApiKeysPage,
});

function CopyButton({ value, label = "Copiar" }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }
  return (
    <Button type="button" variant="outline" size="sm" onClick={copy} className="gap-1.5 rounded-lg">
      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? "Copiado" : label}
    </Button>
  );
}

function ApiKeysPage() {
  const queryClient = useQueryClient();
  const list = useServerFn(listApiKeys);
  const create = useServerFn(createApiKey);
  const revoke = useServerFn(revokeApiKey);
  const destroy = useServerFn(deleteApiKey);

  const { data: keys = [], isLoading } = useQuery({
    queryKey: ["api-keys"],
    queryFn: () => list(),
  });

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("Chave pessoal");
  const [busy, setBusy] = useState(false);
  const [freshKey, setFreshKey] = useState("");
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    setOrigin(window.location.origin);
  }, []);

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["api-keys"] });

  async function generate() {
    setBusy(true);
    try {
      const result = await create({ data: { name: name.trim() || "Chave pessoal" } });
      setFreshKey(result.key);
      await refresh();
    } catch {
      toast.error("Não foi possível gerar a chave.");
    } finally {
      setBusy(false);
    }
  }

  function closeDialog() {
    setOpen(false);
    setFreshKey("");
    setName("Chave pessoal");
  }

  async function handleRevoke(id) {
    await revoke({ data: { id } });
    await refresh();
    toast.success("Chave revogada.");
  }

  async function handleDelete(id) {
    await destroy({ data: { id } });
    await refresh();
    toast.success("Chave excluída.");
  }

  const example = `curl -X POST ${origin || "https://seu-app"}/api/v1/chat \\
  -H "Authorization: Bearer SUA_CHAVE" \\
  -H "Content-Type: application/json" \\
  -d '{"message": "Olá, Jumbo!"}'`;

  return (
    <PageContainer
      title="API keys"
      description="Gere uma chave pessoal e use o Jumbo de qualquer aplicativo, script ou integração."
    >
      <section className="rounded-2xl border border-border bg-card p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.12em] text-muted-foreground">
              Suas chaves
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Cada chave dá acesso à sua conta. Nunca compartilhe publicamente.
            </p>
          </div>
          <Button onClick={() => setOpen(true)} className="h-10 gap-1.5 rounded-xl">
            <Plus className="h-4 w-4" />
            Gerar chave
          </Button>
        </div>

        <div className="mt-4 space-y-2">
          {isLoading ? (
            <div className="h-16 animate-pulse rounded-xl bg-muted/60" />
          ) : keys.length === 0 ? (
            <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-border px-4 py-8 text-center">
              <KeyRound className="h-5 w-5 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Você ainda não tem nenhuma chave.</p>
            </div>
          ) : (
            keys.map((item) => (
              <div
                key={item.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-background/40 px-4 py-3"
              >
                <div className="min-w-0">
                  <p className="flex items-center gap-2 text-sm font-medium">
                    {item.name}
                    <span className="font-mono text-xs text-muted-foreground">••••{item.last4}</span>
                    {item.revoked && (
                      <span className="rounded-full bg-destructive/15 px-2 py-0.5 text-[10px] uppercase tracking-wide text-destructive">
                        revogada
                      </span>
                    )}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {item.last_used_at
                      ? `Último uso: ${new Date(item.last_used_at).toLocaleString("pt-BR")}`
                      : "Ainda não utilizada"}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  {!item.revoked && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="rounded-lg"
                      onClick={() => handleRevoke(item.id)}
                    >
                      Revogar
                    </Button>
                  )}
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    aria-label="Excluir chave"
                    className="rounded-lg text-muted-foreground hover:text-destructive"
                    onClick={() => handleDelete(item.id)}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.12em] text-muted-foreground">
            Como usar
          </h2>
          <CopyButton value={example} label="Copiar exemplo" />
        </div>
        <pre className="mt-3 overflow-x-auto rounded-xl border border-border bg-[#0b0b10] p-3.5 font-mono text-[12.5px] leading-relaxed text-[#e6e6f0]">
          {example}
        </pre>
        <p className="mt-3 text-sm text-muted-foreground">
          Envie o corpo como JSON com o campo <code className="font-mono text-xs">message</code> e receba{" "}
          <code className="font-mono text-xs">{`{ "reply": "..." }`}</code>.
        </p>
      </section>

      <Dialog open={open} onOpenChange={(value) => (value ? setOpen(true) : closeDialog())}>
        <DialogContent className="rounded-2xl">
          <DialogHeader>
            <DialogTitle className="font-heading">{freshKey ? "Chave criada" : "Nova API key"}</DialogTitle>
            <DialogDescription>
              {freshKey
                ? "Copie agora — esta chave não será exibida novamente."
                : "Dê um nome para identificar onde esta chave será usada."}
            </DialogDescription>
          </DialogHeader>

          {freshKey ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2 rounded-xl border border-border bg-background/60 px-3 py-2.5">
                <code className="min-w-0 flex-1 break-all font-mono text-xs">{freshKey}</code>
              </div>
              <CopyButton value={freshKey} label="Copiar chave" />
            </div>
          ) : (
            <div className="space-y-2">
              <Label htmlFor="key-name">Nome da chave</Label>
              <Input
                id="key-name"
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Ex.: Meu bot do Telegram"
                className="h-11"
              />
            </div>
          )}

          <DialogFooter>
            {freshKey ? (
              <Button onClick={closeDialog} className="rounded-xl">
                Concluir
              </Button>
            ) : (
              <Button onClick={generate} disabled={busy} className="rounded-xl">
                {busy ? "Criando..." : "Criar chave"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}