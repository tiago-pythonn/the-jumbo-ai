import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import AiInstructions from "@/components/admin/AiInstructions";
import CodeFiles from "@/components/admin/CodeFiles";
import DataExport from "@/components/admin/DataExport";
import PageContainer from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";
import { bootstrapAdmin, listUsers, setUserRole } from "@/lib/admin-fns";

export const Route = createFileRoute("/_authed/admin")({
  head: () => ({ meta: [{ title: "Administração · Jumbo" }] }),
  component: AdminPage,
});

function AdminPage() {
  const queryClient = useQueryClient();
  const { refresh } = useAuth();
  const list = useServerFn(listUsers);
  const setRole = useServerFn(setUserRole);
  const claim = useServerFn(bootstrapAdmin);

  const { data, isLoading } = useQuery({
    queryKey: ["admin", "users"],
    queryFn: () => list(),
  });

  async function makeAdmin() {
    const result = await claim();
    if (result.admin) {
      await refresh();
      await queryClient.invalidateQueries({ queryKey: ["admin", "users"] });
      toast.success("Agora você é administrador.");
    } else {
      toast.error("Já existe um administrador neste app.");
    }
  }

  async function changeRole(userId, role) {
    await setRole({ data: { userId, role } });
    await queryClient.invalidateQueries({ queryKey: ["admin", "users"] });
    toast.success("Permissão atualizada.");
  }

  if (isLoading) {
    return (
      <PageContainer title="Administração">
        <div className="h-40 animate-pulse rounded-2xl bg-muted/60" />
      </PageContainer>
    );
  }

  if (!data?.authorized) {
    return (
      <PageContainer title="Administração" description="Área restrita a administradores.">
        <div className="rounded-2xl border border-border bg-card p-6 text-center">
          <ShieldCheck className="mx-auto h-6 w-6 text-primary" />
          <p className="mt-3 text-sm text-muted-foreground">
            Este app ainda não tem uma conta administradora. Ative a sua agora para gerenciar usuários.
          </p>
          <Button onClick={makeAdmin} className="mt-4 rounded-xl">
            Tornar-me administrador
          </Button>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer title="Administração" description="Gerencie as permissões dos usuários do Jumbo.">
      <AiInstructions />
      <DataExport />
      <CodeFiles />
      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-xs uppercase tracking-[0.12em] text-muted-foreground">
              <th className="px-4 py-3 font-medium">Usuário</th>
              <th className="px-4 py-3 font-medium">Permissão</th>
            </tr>
          </thead>
          <tbody>
            {data.users.map((item) => (
              <tr key={item.id} className="border-b border-border/60 last:border-0">
                <td className="px-4 py-3">
                  <p className="font-medium">{item.full_name || "Sem nome"}</p>
                  <p className="text-xs text-muted-foreground">{item.email}</p>
                </td>
                <td className="px-4 py-3">
                  <select
                    value={item.role}
                    onChange={(event) => changeRole(item.id, event.target.value)}
                    className="h-9 rounded-lg border border-border bg-background px-2 text-sm outline-none focus:border-primary/50"
                  >
                    <option value="user">Usuário</option>
                    <option value="admin">Administrador</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </PageContainer>
  );
}