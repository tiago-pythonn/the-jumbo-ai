import { createFileRoute, notFound } from "@tanstack/react-router";
import ChatView from "@/components/chat/ChatView";
import { getConversation } from "@/lib/chat-fns";

export const Route = createFileRoute("/_authed/c/$conversationId")({
  loader: async ({ params }) => {
    const data = await getConversation({ data: { id: params.conversationId } });
    if (!data) throw notFound();
    return data;
  },
  head: ({ loaderData }) => ({
    meta: [{ title: `${loaderData?.conversation?.title ?? "Chat"} · Jumbo` }],
  }),
  component: ConversationPage,
});

function ConversationPage() {
  const { conversation, messages } = Route.useLoaderData();

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-14 shrink-0 items-center border-b border-border px-4">
        <p className="line-clamp-1 font-heading text-sm font-medium">{conversation.title}</p>
      </div>
      <div className="min-h-0 flex-1">
        <ChatView conversationId={conversation.id} initialMessages={messages} />
      </div>
    </div>
  );
}