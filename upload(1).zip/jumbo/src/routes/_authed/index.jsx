import { createFileRoute } from "@tanstack/react-router";
import ChatView from "@/components/chat/ChatView";

export const Route = createFileRoute("/_authed/")({
  head: () => ({ meta: [{ title: "Jumbo — Novo chat" }] }),
  component: NewChatPage,
});

function NewChatPage() {
  return <ChatView />;
}