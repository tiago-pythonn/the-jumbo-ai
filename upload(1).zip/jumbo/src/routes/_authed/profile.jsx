import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import PageContainer from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/AuthContext";

export const Route = createFileRoute("/_authed/profile")({
  head: () => ({ meta: [{ title: "Perfil e configurações · Jumbo" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, refresh } = useAuth();
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    setName(user?.full_name ?? "");
  }, [user?.full_name]);

  async function saveName(event) {
    event.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    try {
      await base44.auth.updateMe({ full_name: name.trim() });
      await refresh();
      toast.success("Perfil atualizado.");
    } catch {
      toast.error("Não foi possível salvar seu nome.");
    } finally {
      setSaving(false);
    }
  }

  async function sendReset() {
    setSending(true);
    try {
      await base44.auth.resetPasswordRequest(user.email);
      toast.success("Enviamos um link de redefinição para o seu e-mail.");
    } catch {
      toast.success("Enviamos um link de redefinição para o seu e-mail.");
    } finally {
      setSending(false);
    }
  }

  return (
    <PageContainer title="Perfil e configurações" description="Gerencie seus dados de acesso ao Jumbo.">
      <section className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.12em] text-muted-foreground">
          Conta
        </h2>
        <form onSubmit={saveName} className="mt-4 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="profile-name">Nome</Label>
            <Input
              id="profile-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="Seu nome"
              className="h-11"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="profile-email">E-mail</Label>
            <Input id="profile-email" value={user?.email ?? ""} disabled className="h-11" />
          </div>
          <div className="flex items-center gap-3">
            <Button type="submit" disabled={saving} className="h-10 rounded-xl">
              {saving ? "Salvando..." : "Salvar alterações"}
            </Button>
            <span className="rounded-full border border-border px-2.5 py-1 text-[11px] uppercase tracking-wide text-muted-foreground">
              {user?.role === "admin" ? "Administrador" : "Usuário"}
            </span>
          </div>
        </form>
      </section>

      <section className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.12em] text-muted-foreground">
          Senha
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Para trocar sua senha, enviaremos um link seguro para o seu e-mail.
        </p>
        <Button
          type="button"
          variant="outline"
          onClick={sendReset}
          disabled={sending}
          className="mt-4 h-10 rounded-xl"
        >
          {sending ? "Enviando..." : "Enviar link de redefinição"}
        </Button>
      </section>
    </PageContainer>
  );
}